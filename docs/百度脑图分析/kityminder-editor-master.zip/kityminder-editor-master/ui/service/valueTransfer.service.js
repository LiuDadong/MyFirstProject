angular.module('kityminderEditor')
    .service('valueTransfer', function() {
        return {};
    });