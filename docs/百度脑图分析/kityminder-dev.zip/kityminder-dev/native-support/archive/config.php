<?php

return array(
    'savepath' => dirname( __FILE__ ) . '/upload/'
);