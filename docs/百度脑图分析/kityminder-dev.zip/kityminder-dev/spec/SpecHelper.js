//beforeEach( function () {
//    // customMatcher 例子
//    this.addMatchers( {
//        //用的时候这么用:
//        //expect('***').customMatchers(true);
//        //expect('***').not.customMatchers(true);
////        customMatchers: function ( expected ) {
////            return expected === true;
////        },
//
//    } );
//} );
