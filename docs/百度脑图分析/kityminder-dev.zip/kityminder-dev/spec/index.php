<?php
/**
 * Created by PhpStorm.
 * User: dongyancen
 * Date: 14-1-15
 * Time: 下午6:50
 */
Header('Location:../spec/tools/list.php');
?>