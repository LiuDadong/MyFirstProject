/**
 * Created by dongyancen on 13-12-30.
 */
describe("connect", function () {

    it("KityMinder 已定义", function () {
        expect(KityMinder).toBeDefined();
    });
});
