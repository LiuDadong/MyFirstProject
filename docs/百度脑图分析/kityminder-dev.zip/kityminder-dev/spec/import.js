/**
 * Created by dongyancen on 13-12-27.
 */
///import core/kityminder;
///import core/utils;
///import core/command;
///import core/node;
///import core/module;
///import core/event;
///import core/minder;
///import core/minder.data.compatibility;
///import core/minder.data;
///import core/minder.event;
///import core/minder.module;
///import core/minder.command;
///import core/minder.node;
///import core/minder.select;
///import core/keymap;
///import core/minder.lang;
///import core/minder.defaultoptions;
///import core/minder.preference;
///import core/browser;
///import core/layout;
///import core/connect;
///import core/render;
///import core/theme;
///import core/template;
///import layout/default;
///import layout/default.connect;
///import layout/bottom;
///import layout/filetree;
///import theme/default;
///import theme/snow;
///import theme/fresh;
///import template/structure;
///import module/node;
///import module/text;
///import module/expand;
///import module/outline;
///import module/geometry;
///import module/history;
///import module/progress;
///import module/priority;
///import module/image;
///import module/resource;
///import module/view;
///import module/dragtree;
///import module/keyboard;
///import module/select;
///import module/history;
///import module/editor;
///import module/editor.keyboard;
///import module/editor.range;
///import module/editor.receiver;
///import module/editor.selection;
///import module/basestyle;
///import module/font;
///import module/zoom;
///import module/hyperlink;
///import module/arrange;
///import module/paste;
///import module/style;
///import protocal/xmind;
///import protocal/freemind;
///import protocal/mindmanager;
///import protocal/plain;
///import protocal/json;
///import protocal/png;
///import protocal/svg;
///import ui/ui;
///import ui/eve;
///import ui/fuix;
///import ui/fiox;
///import ui/doc;


///import ui/widget/commandbutton;
///import ui/widget/commandbuttonset;
///import ui/widget/commandinputmenu;
///import ui/widget/friendlytimespan;
///import ui/widget/locallist;
///import ui/widget/netdiskfinder;
///import ui/widget/menutab;


///import ui/menu/menu;
///import ui/menu/header;
///import ui/menu/default;

///import ui/menu/new/new;
///import ui/menu/open/open;
///import ui/menu/open/recent;
///import ui/menu/open/netdisk;
///import ui/menu/open/local;
///import ui/menu/open/draft;
///import ui/menu/save/save;
///import ui/menu/save/netdisk;

///import ui/menu/save/download;
///import ui/menu/share/share;
///import ui/topbar/history;
///import ui/topbar/user;
///import ui/topbar/search;
///import ui/topbar/title;
///import ui/ribbon/tabs;
///import ui/ribbon/idea/insert;

///import ui/ribbon/idea/arrange;
///import ui/ribbon/idea/operation;
///import ui/ribbon/idea/attachment;
///import ui/ribbon/idea/link;
///import ui/ribbon/idea/image;
///import ui/ribbon/idea/priority;
///import ui/ribbon/idea/progress;
///import ui/ribbon/idea/resource;

///import ui/ribbon/appearence/template;
///import ui/ribbon/appearence/theme;
///import ui/ribbon/appearence/layout;
///import ui/ribbon/appearence/style;
///import ui/ribbon/appearence/font;
///import ui/ribbon/appearence/color;
///import ui/ribbon/view/level;


