/**
 *
 * Created by Ryan on 14-9-3.
 */
zip.inflateJSPath = '../../../lib/inflate.js';
