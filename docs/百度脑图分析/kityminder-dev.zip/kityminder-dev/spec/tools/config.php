<?php
/**
 * Created by JetBrains PhpStorm.
 * User: dongyancen
 * Date: 13-10-10
 * Time: 上午1:50
 * To change this template use File | Settings | File Templates.
 */
class Config

{
    public static $projroot = "../../";
    //相对于projroot的路径
    public static $src_PATH = "src/" ;

    public static $test_PATH = "spec/";

    public static $helperFiles =  array( "SpecHelper.js" );
}