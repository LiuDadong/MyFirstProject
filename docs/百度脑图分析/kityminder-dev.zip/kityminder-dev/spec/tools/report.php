<?php
/**
 * Created by JetBrains PhpStorm.
 * User: dongyancen
 * Date: 13-10-17
 * Time: 下午6:28
 * To change this template use File | Settings | File Templates.
 */
error_reporting(E_ERROR|E_WARNING);
function report()
{
    return;
}
report();